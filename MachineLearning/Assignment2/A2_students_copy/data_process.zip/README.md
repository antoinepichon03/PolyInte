## INF8245AE Assignment 2

Hi everyone, for working on this assignment, you will need to setup your environment and install the necessary dependencies.

1. Create your virtual or anaconda/miniconda environment.
2. Run ```pip install -r requirements.txt```.


Please do not import any extra libraries in the files. All the necessary libraries are already imported for you. 

When uploading your assignment, only compress the ```*.py``` files, do not include data folders/files or environment files.