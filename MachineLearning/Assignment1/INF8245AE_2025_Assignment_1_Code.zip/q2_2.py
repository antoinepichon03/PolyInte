from q2_1 import *
import pandas as pd
import numpy as np

# Write your code here ...
# Not autograded — function names and structure are flexible.