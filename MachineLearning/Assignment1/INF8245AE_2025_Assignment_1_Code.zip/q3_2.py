import numpy as np
import matplotlib.pyplot as plt
from q3_1 import gradient_descent_ridge
from q1_1 import rmse

# Write your code here ...
# Not autograded — function names and structure are flexible.
